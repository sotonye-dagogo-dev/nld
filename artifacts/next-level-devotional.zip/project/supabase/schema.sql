-- ============================================================================
-- NEXT LEVEL DEVOTIONAL — Supabase schema
-- Run this once in your Supabase project: Dashboard → SQL Editor → New query
-- → paste this whole file → Run.
-- ============================================================================

-- Extensions -----------------------------------------------------------------
create extension if not exists "uuid-ossp";

-- ============================================================================
-- PROFILES
-- One row per authenticated user. Created automatically on signup (trigger
-- below). "role" controls who can answer questions in the Q&A feature:
-- 'member' (default), 'pastor', or 'admin'.
-- ============================================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  role text not null default 'member' check (role in ('member','pastor','admin')),
  bio text default '',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Profiles are viewable by any signed-in user"
  on public.profiles for select
  using (auth.role() = 'authenticated');

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- Auto-create a profile row whenever a new auth user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Small helper used inside RLS policies to check role without recursive
-- select-policy issues.
create or replace function public.current_user_role()
returns text
language sql stable security definer set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- ============================================================================
-- PURCHASES
-- Records the one-time payment that unlocks the full 30-day devotional.
-- Rows are created by the Netlify function `paystack-init` (status:
-- 'pending') and flipped to 'success' by `paystack-webhook` once Paystack
-- confirms payment. Only the service role (used by the serverless
-- functions) may write status — end users cannot mark themselves as paid.
-- ============================================================================
create table if not exists public.purchases (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null,              -- in kobo (NGN) / smallest currency unit
  currency text not null default 'NGN',
  paystack_reference text unique not null,
  status text not null default 'pending' check (status in ('pending','success','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.purchases enable row level security;

create policy "Users can view their own purchases"
  on public.purchases for select
  using (auth.uid() = user_id);

create policy "Users can create a pending purchase for themselves"
  on public.purchases for insert
  with check (auth.uid() = user_id and status = 'pending');

-- NOTE: there is intentionally no UPDATE policy for regular users.
-- The webhook uses the service_role key, which bypasses RLS entirely.

-- Convenience view: has this user paid?
create or replace view public.my_access as
select
  auth.uid() as user_id,
  exists (
    select 1 from public.purchases p
    where p.user_id = auth.uid() and p.status = 'success'
  ) as has_full_access;

-- ============================================================================
-- QUESTIONS & ANSWERS  (live Q&A with pastors/church members)
-- ============================================================================
create table if not exists public.questions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer check (day_number between 1 and 30),
  question text not null check (char_length(question) between 3 and 2000),
  status text not null default 'open' check (status in ('open','answered')),
  created_at timestamptz not null default now()
);

alter table public.questions enable row level security;

create policy "Questions are viewable by any signed-in user"
  on public.questions for select
  using (auth.role() = 'authenticated');

create policy "Users can post their own questions"
  on public.questions for insert
  with check (auth.uid() = user_id);

create policy "Users can delete their own questions"
  on public.questions for delete
  using (auth.uid() = user_id);

create table if not exists public.answers (
  id uuid primary key default uuid_generate_v4(),
  question_id uuid not null references public.questions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  answer text not null check (char_length(answer) between 1 and 4000),
  created_at timestamptz not null default now()
);

alter table public.answers enable row level security;

create policy "Answers are viewable by any signed-in user"
  on public.answers for select
  using (auth.role() = 'authenticated');

-- Anyone signed in can answer (per the brief: "answered by church members
-- and pastors"). If you'd rather restrict answering to pastors/admins only,
-- swap the USING clause below for:
--   public.current_user_role() in ('pastor','admin')
create policy "Signed-in users can answer questions"
  on public.answers for insert
  with check (auth.uid() = user_id);

-- Mark a question answered whenever an answer is added.
create or replace function public.mark_question_answered()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.questions set status = 'answered' where id = new.question_id;
  return new;
end;
$$;

drop trigger if exists on_answer_created on public.answers;
create trigger on_answer_created
  after insert on public.answers
  for each row execute procedure public.mark_question_answered();

-- ============================================================================
-- SHARES  (members sharing learnings / summaries) + comments + likes
-- ============================================================================
create table if not exists public.shares (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer check (day_number between 1 and 30),
  content text not null check (char_length(content) between 3 and 3000),
  created_at timestamptz not null default now()
);

alter table public.shares enable row level security;

create policy "Shares are viewable by any signed-in user"
  on public.shares for select
  using (auth.role() = 'authenticated');

create policy "Users can post their own shares"
  on public.shares for insert
  with check (auth.uid() = user_id);

create policy "Users can delete their own shares"
  on public.shares for delete
  using (auth.uid() = user_id);

create table if not exists public.share_comments (
  id uuid primary key default uuid_generate_v4(),
  share_id uuid not null references public.shares(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 1000),
  created_at timestamptz not null default now()
);

alter table public.share_comments enable row level security;

create policy "Comments are viewable by any signed-in user"
  on public.share_comments for select
  using (auth.role() = 'authenticated');

create policy "Users can post their own comments"
  on public.share_comments for insert
  with check (auth.uid() = user_id);

create table if not exists public.share_likes (
  share_id uuid not null references public.shares(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (share_id, user_id)
);

alter table public.share_likes enable row level security;

create policy "Likes are viewable by any signed-in user"
  on public.share_likes for select
  using (auth.role() = 'authenticated');

create policy "Users can like as themselves"
  on public.share_likes for insert
  with check (auth.uid() = user_id);

create policy "Users can unlike their own like"
  on public.share_likes for delete
  using (auth.uid() = user_id);

-- ============================================================================
-- READING BUDDIES
-- A simple opt-in queue: users add themselves to `buddy_requests`; the first
-- two open, unmatched requests get paired into a `buddy_matches` row (done
-- client-side in js/buddies.js for simplicity — see comment there for how to
-- move this server-side later if you want it race-condition-proof).
-- ============================================================================
create table if not exists public.buddy_requests (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  preferred_time text default '',
  note text default '',
  status text not null default 'open' check (status in ('open','matched','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.buddy_requests enable row level security;

create policy "Buddy requests viewable by any signed-in user"
  on public.buddy_requests for select
  using (auth.role() = 'authenticated');

create policy "Users manage their own buddy request"
  on public.buddy_requests for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own buddy request"
  on public.buddy_requests for update
  using (auth.uid() = user_id);

-- The pairing flow in js/buddies.js has one user flip *another* user's open
-- request to 'matched' at the moment they match with them (simple
-- client-side queue — see comment in buddies.html for the tradeoffs). That
-- needs its own, narrower policy: any signed-in user may move someone
-- else's request from 'open' to 'matched', nothing else.
create policy "Signed-in users can claim an open request when matching"
  on public.buddy_requests for update
  using (status = 'open')
  with check (status = 'matched');

create table if not exists public.buddy_matches (
  id uuid primary key default uuid_generate_v4(),
  user_a uuid not null references auth.users(id) on delete cascade,
  user_b uuid not null references auth.users(id) on delete cascade,
  matched_at timestamptz not null default now()
);

alter table public.buddy_matches enable row level security;

create policy "Users can view matches they are part of"
  on public.buddy_matches for select
  using (auth.uid() = user_a or auth.uid() = user_b);

create policy "Signed-in users can create a match"
  on public.buddy_matches for insert
  with check (auth.uid() = user_a or auth.uid() = user_b);

-- ============================================================================
-- READING PROGRESS  (marks a day "done" for the day-grid checkmarks)
-- ============================================================================
create table if not exists public.reading_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer not null check (day_number between 1 and 30),
  completed_at timestamptz not null default now(),
  primary key (user_id, day_number)
);

alter table public.reading_progress enable row level security;

create policy "Users can view their own progress"
  on public.reading_progress for select
  using (auth.uid() = user_id);

create policy "Users can mark their own progress"
  on public.reading_progress for insert
  with check (auth.uid() = user_id);

create policy "Users can remove their own progress"
  on public.reading_progress for delete
  using (auth.uid() = user_id);

-- ============================================================================
-- Realtime — enable so Q&A and shares update live in the UI.
-- (Dashboard → Database → Replication also works instead of this block.)
-- ============================================================================
alter publication supabase_realtime add table public.questions;
alter publication supabase_realtime add table public.answers;
alter publication supabase_realtime add table public.shares;
alter publication supabase_realtime add table public.share_comments;

-- ============================================================================
-- To promote a member to pastor/admin (so they can be flagged as clergy in
-- the UI — everyone can currently answer questions per the policy above),
-- run, after they've signed up at least once:
--   update public.profiles set role = 'pastor' where id = '<their-user-uuid>';
-- ============================================================================
