// Netlify Function: POST /.netlify/functions/paystack-init
//
// Called from account.html right before opening the Paystack popup. It:
//   1. Generates a unique payment reference.
//   2. Records a 'pending' row in Supabase `purchases` (using the SERVICE
//      ROLE key, which bypasses RLS — this function is the only place that
//      key is ever used).
//   3. Returns the reference to the browser, which passes it to Paystack.
//
// Required environment variables (set in Netlify → Site settings →
// Environment variables — see docs/SETUP_GUIDE.md):
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY   (Project Settings → API → service_role — SECRET, never expose client-side)
//   PAYSTACK_SECRET_KEY         (Paystack → Settings → API Keys — SECRET)

const { createClient } = require('@supabase/supabase-js');

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { user_id, email, amount, currency } = JSON.parse(event.body || '{}');
    if (!user_id || !email || !amount) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing user_id, email, or amount.' }) };
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const paystackSecret = process.env.PAYSTACK_SECRET_KEY;

    if (!supabaseUrl || !serviceKey || !paystackSecret) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Server is not configured yet. The church admin needs to set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, and PAYSTACK_SECRET_KEY in Netlify environment variables.' }),
      };
    }

    const supabase = createClient(supabaseUrl, serviceKey);

    const reference = `nld_${user_id.slice(0, 8)}_${Date.now()}`;

    const { error: insertError } = await supabase.from('purchases').insert({
      user_id,
      amount,
      currency: currency || 'NGN',
      paystack_reference: reference,
      status: 'pending',
    });
    if (insertError) {
      return { statusCode: 500, body: JSON.stringify({ error: insertError.message }) };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ reference }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
