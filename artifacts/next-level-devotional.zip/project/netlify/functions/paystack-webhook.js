// Netlify Function: POST /.netlify/functions/paystack-webhook
//
// Set this exact URL as your webhook in Paystack → Settings → API Keys &
// Webhooks → Webhook URL:
//   https://YOUR-SITE-NAME.netlify.app/.netlify/functions/paystack-webhook
//
// Paystack calls this automatically after a payment completes. We verify
// the request really came from Paystack (HMAC signature check), then flip
// the matching `purchases` row to 'success' using the Supabase service role
// key. This is the ONLY place a purchase is ever marked successful — the
// browser can never do this directly, which is what makes the paywall safe.

const crypto = require('crypto');
const { createClient } = require('@supabase/supabase-js');

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!paystackSecret || !supabaseUrl || !serviceKey) {
    console.error('Missing environment variables for paystack-webhook.');
    return { statusCode: 500, body: 'Server not configured.' };
  }

  // Verify signature — Paystack signs the raw body with your secret key.
  const signature = event.headers['x-paystack-signature'];
  const expected = crypto
    .createHmac('sha512', paystackSecret)
    .update(event.body)
    .digest('hex');

  if (!signature || signature !== expected) {
    return { statusCode: 401, body: 'Invalid signature.' };
  }

  const payload = JSON.parse(event.body);

  if (payload.event === 'charge.success') {
    const reference = payload.data.reference;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { error } = await supabase
      .from('purchases')
      .update({ status: 'success', updated_at: new Date().toISOString() })
      .eq('paystack_reference', reference);

    if (error) {
      console.error('Failed to update purchase:', error);
      return { statusCode: 500, body: 'Database update failed.' };
    }
  }

  return { statusCode: 200, body: 'ok' };
};
