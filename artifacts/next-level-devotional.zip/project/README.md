# Next Level Devotional

A website for **Harvesters International Christian Centre's** *Next Level
Online Prayers* — 30 Days of Prayer & Fasting devotional with Pastor Bolaji
Idowu.

This is a static website (plain HTML/CSS/JS — no build step) that you can
host for free on **Netlify** or **GitHub Pages**, backed by a free-tier
**Supabase** project for accounts, live Q&A, testimonies, reading buddies,
and progress tracking, plus **Paystack** for the one-time payment that
unlocks the full 30 days.

**➡️ Start here: [docs/SETUP_GUIDE.md](docs/SETUP_GUIDE.md)** — a full,
step-by-step walkthrough for getting this live, written for someone setting
this up for the first time.

## What's included

| Feature (from the brief) | Where it lives |
|---|---|
| 1. Host the devotional | `index.html`, `day.html`, `js/devotional-data.js` |
| 2. Paid devotional | `account.html` (Paystack) + `netlify/functions/` |
| 3. Live Q&A with pastors/members | `community.html` |
| 4. Share learnings/summaries | `shares.html` |
| 5. Reading buddies | `buddies.html` |
| 6. Sermon of the day | `js/sermons.js` (video embed per day) |

## Project structure

```
index.html              Home page — the 30-day grid
day.html                 The devotional reader (?d=1 … ?d=30)
community.html            Live Q&A
shares.html               Testimonies / learnings feed
buddies.html               Reading buddy matching
account.html                Sign in / sign up / payment

css/styles.css                All styling — one file, no build step

js/config.js                   ⚠️ EDIT THIS — your Supabase & Paystack keys
js/sermons.js                    ⚠️ EDIT THIS — sermon video link per day
js/devotional-data.js              Devotional content (auto-generated, see below)
js/devotional.js                     Content helpers (days, parts)
js/supabase-client.js                  Connects to Supabase
js/auth.js                               Sign in/out, nav bar, access checks

supabase/schema.sql          Run this once in your Supabase project

netlify/functions/
  paystack-init.js            Starts a payment (keeps secret key server-side)
  paystack-webhook.js           Confirms a payment (keeps secret key server-side)
netlify.toml                       Netlify config

parse-source/                Scripts used to extract devotional-data.js from
                              the church's Word document. Only needed again
                              if the devotional text is revised — see its
                              README.
```

## The two files you'll actually edit

Everything content-related lives in two small files:

- **`js/config.js`** — Supabase URL/key, Paystack public key, price, how many
  days are free to preview.
- **`js/sermons.js`** — paste a YouTube embed link next to each day number to
  show that day's sermon on the reader page.

Everything else works out of the box.

## Local preview

No build step needed — just serve the folder:

```bash
cd next-level-devotional
python3 -m http.server 8080
# open http://localhost:8080
```

(Opening `index.html` directly by double-clicking will mostly work too, but
some browsers restrict `fetch`/module behavior on `file://` URLs — a local
server avoids that.)

## Deploying

See **[docs/SETUP_GUIDE.md](docs/SETUP_GUIDE.md)** for the full walkthrough,
including Supabase, Paystack, and Netlify deployment (GitHub Pages works too
for the content-only parts, but Paystack payment requires Netlify's free
serverless functions, since Paystack's secret key must never sit in
browser-visible code).
