/* Initializes the shared Supabase client. Loaded after config.js and the
   Supabase UMD bundle on every page. */
(function () {
  const cfg = window.APP_CONFIG;
  if (!cfg || cfg.SUPABASE_URL.includes('YOUR-PROJECT-REF')) {
    console.warn(
      '[Next Level Devotional] js/config.js still has placeholder Supabase ' +
      'credentials. Accounts, Q&A, sharing, buddies, and payment will not ' +
      'work until you fill them in. The devotional reading itself still works.'
    );
  }
  window.supabaseClient = (cfg && window.supabase)
    ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY)
    : null;
})();
