/* ============================================================================
   SERMON OF THE DAY
   Add a YouTube (or Vimeo) link for each day's live/recorded sermon here.
   Leave a day out of this object (or leave it as '') and the reader page
   simply won't show a sermon player for that day — nothing breaks.

   How to get a YouTube embed link:
     1. Open the video on youtube.com
     2. Click Share → Embed
     3. Copy the URL inside src="..." — it looks like
        https://www.youtube.com/embed/XXXXXXXXXXX
   ============================================================================ */
window.SERMONS = {
  // 1: 'https://www.youtube.com/embed/XXXXXXXXXXX',
  // 2: 'https://www.youtube.com/embed/XXXXXXXXXXX',
};
