/* Devotional content helpers. Relies on window.DEVOTIONAL_DAYS from
   js/devotional-data.js (generated from the church's Word document — see
   /parse-source/ in the repo root for the extraction script, and re-run it
   if the devotional text is ever revised). */

const PARTS = [
  { label: 'Part 1 — New Beginnings', range: [1, 7] },
  { label: 'Part 2 — Divine Life', range: [8, 11] },
  { label: 'Part 3 — Living In Freedom', range: [12, 16] },
  { label: 'Part 4 — Walking In Purpose', range: [17, 21] },
  { label: 'Part 5 — Walking In The Supernatural', range: [22, 26] },
  { label: 'Part 6 — Reigning In Life', range: [27, 30] },
];

function partForDay(dayNum) {
  const p = PARTS.find(p => dayNum >= p.range[0] && dayNum <= p.range[1]);
  return p ? p.label : '';
}

function getDay(num) {
  return window.DEVOTIONAL_DAYS.find(d => d.day === Number(num));
}

function totalDays() {
  return window.DEVOTIONAL_DAYS.length;
}
