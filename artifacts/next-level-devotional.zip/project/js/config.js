/* ============================================================================
   NEXT LEVEL DEVOTIONAL — configuration
   Fill these in after you've created your Supabase project and Paystack
   account. See docs/SETUP_GUIDE.md for exact step-by-step instructions.
   None of these values are secret — they are safe to ship in client code.
   (The Paystack SECRET key and Supabase SERVICE ROLE key are NEVER put here;
   they live only in Netlify's environment variables for the serverless
   functions.)
   ============================================================================ */

window.APP_CONFIG = {
  // Supabase → Project Settings → API
  SUPABASE_URL: 'https://YOUR-PROJECT-REF.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR-SUPABASE-ANON-PUBLIC-KEY',

  // Paystack → Settings → API Keys & Webhooks (the PUBLIC key only)
  PAYSTACK_PUBLIC_KEY: 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',

  // Price to unlock the full 30-day devotional, in your currency's smallest
  // unit (kobo for NGN, so 500000 = ₦5,000). Set to 0 to make everything free.
  DEVOTIONAL_PRICE: 500000,
  DEVOTIONAL_CURRENCY: 'NGN',

  // How many days are readable for free before the paywall appears.
  FREE_PREVIEW_DAYS: 3,

  CHURCH_NAME: 'Harvesters International Christian Centre',
  APP_NAME: 'Next Level Devotional',
};
