/* ============================================================================
   Auth — thin wrapper around Supabase Auth, plus shared nav / gating helpers
   used by every page.
   ============================================================================ */
const Auth = (function () {
  const sb = () => window.supabaseClient;

  async function getSession() {
    if (!sb()) return null;
    const { data } = await sb().auth.getSession();
    return data.session || null;
  }

  async function getProfile() {
    const session = await getSession();
    if (!session) return null;
    const { data, error } = await sb()
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();
    if (error) {
      console.error('getProfile error', error);
      return null;
    }
    return data;
  }

  async function hasFullAccess() {
    const session = await getSession();
    if (!session) return false;
    if (window.APP_CONFIG.DEVOTIONAL_PRICE === 0) return true;
    const { data, error } = await sb()
      .from('purchases')
      .select('status')
      .eq('user_id', session.user.id)
      .eq('status', 'success')
      .limit(1);
    if (error) {
      console.error('hasFullAccess error', error);
      return false;
    }
    return data && data.length > 0;
  }

  async function signUp(email, password, fullName) {
    const { data, error } = await sb().auth.signUp({
      email, password,
      options: { data: { full_name: fullName } },
    });
    return { data, error };
  }

  async function signIn(email, password) {
    const { data, error } = await sb().auth.signInWithPassword({ email, password });
    return { data, error };
  }

  async function signOut() {
    await sb().auth.signOut();
    window.location.href = 'index.html';
  }

  function requireAuthOrRedirect(session) {
    if (!session) {
      window.location.href = 'account.html';
      return false;
    }
    return true;
  }

  return { getSession, getProfile, hasFullAccess, signUp, signIn, signOut, requireAuthOrRedirect };
})();

/* ---------------------------------------------------------------------------
   Shared chrome: top nav + mobile toggle + footer, injected on every page.
   --------------------------------------------------------------------------- */
async function renderChrome() {
  const cfg = window.APP_CONFIG;
  const navEl = document.getElementById('site-nav');
  const footEl = document.getElementById('site-footer');
  const path = window.location.pathname.split('/').pop() || 'index.html';

  const session = await Auth.getSession();

  const links = [
    ['index.html', 'Devotional'],
    ['community.html', 'Q&A'],
    ['shares.html', 'Testimonies'],
    ['buddies.html', 'Reading Buddies'],
  ];

  if (navEl) {
    navEl.innerHTML = `
      <div class="nav__inner">
        <a href="index.html" class="nav__brand">${cfg.APP_NAME.split(' ')[0]}<span> ${cfg.APP_NAME.split(' ').slice(1).join(' ')}</span></a>
        <button class="nav__toggle" id="nav-toggle" aria-label="Menu">☰</button>
        <nav class="nav__links" id="nav-links">
          ${links.map(([href, label]) => `<a class="nav__link ${path === href ? 'is-active' : ''}" href="${href}">${label}</a>`).join('')}
          <a class="nav__link ${path === 'account.html' ? 'is-active' : ''}" href="account.html">${session ? 'My Account' : 'Sign In'}</a>
        </nav>
      </div>`;
    const toggle = document.getElementById('nav-toggle');
    const navLinks = document.getElementById('nav-links');
    if (toggle) toggle.addEventListener('click', () => navLinks.classList.toggle('is-open'));
  }

  if (footEl) {
    footEl.innerHTML = `
      <div class="container">
        <div class="footer__top">
          <div>
            <div class="footer__brand">${cfg.APP_NAME}</div>
            <div class="mt-8">${cfg.CHURCH_NAME}</div>
          </div>
          <div class="flex gap-16" style="flex-wrap:wrap;">
            ${links.map(([href, label]) => `<a href="${href}">${label}</a>`).join('')}
          </div>
        </div>
        <div>© ${new Date().getFullYear()} ${cfg.CHURCH_NAME}. 30 Days of Prayer &amp; Fasting with Pastor Bolaji Idowu.</div>
      </div>`;
  }
}
