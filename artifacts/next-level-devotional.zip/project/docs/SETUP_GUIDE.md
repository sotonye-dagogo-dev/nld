# Setup Guide

This walks through getting the whole site live: content first (free, five
minutes), then accounts/Q&A/sharing/buddies (free, ~15 minutes), then
payment (~10 minutes). You can stop after any stage — each one adds a
feature without breaking what came before.

Total cost to run this: **$0/month** on the free tiers of Netlify and
Supabase, up to generous limits (Supabase free tier: 50,000 monthly active
users, 500MB database — far more than a single church needs to start).
Paystack takes its standard transaction fee only when someone pays.

---

## Stage 0 — Get the site live (content only, no accounts yet)

This gets the devotional itself readable by everyone, right away.

1. Create a free [Netlify](https://netlify.com) account (you can sign up
   with GitHub, GitLab, or email).
2. Go to **Sites → Add new site → Deploy manually**.
3. Drag the whole `next-level-devotional` folder onto the upload area.
4. Netlify gives you a live URL like `https://random-name-123.netlify.app`
   within seconds. That's it — the devotional is live.
5. Optional: **Site settings → Change site name** to something like
   `next-level-devotional`, or **Domain settings → Add a custom domain** if
   the church has one (e.g. `devotional.harvestersng.org`).

At this point, everyone can read every day for free (no paywall shows until
Stage 2, and Q&A/sharing/buddies pages will say they're "not connected yet"
until Stage 1). If that's genuinely all you need, you're done.

---

## Stage 1 — Turn on accounts, Q&A, sharing, and reading buddies (Supabase)

### 1.1 Create the Supabase project

1. Go to [supabase.com](https://supabase.com) → **Start your project** →
   sign up (free).
2. **New project**. Pick any name (e.g. `next-level-devotional`), set a
   strong database password (save it somewhere — you likely won't need it
   again, but keep it safe), and pick the region closest to Nigeria (e.g.
   an EU region tends to have the lowest latency to West Africa on
   Supabase's current regions — any region works, this just affects speed).
3. Wait ~2 minutes for the project to finish provisioning.

### 1.2 Run the database schema

1. In your new project, open **SQL Editor** (left sidebar) → **New query**.
2. Open `supabase/schema.sql` from this project in a text editor, copy the
   whole file, and paste it into the SQL editor.
3. Click **Run**. You should see "Success. No rows returned." If you get an
   error about `supabase_realtime` at the very bottom, that's safe to
   ignore — it just means realtime was already on for those tables; you can
   also skip the last four `alter publication` lines and instead go to
   **Database → Replication** and toggle on `questions`, `answers`,
   `shares`, `share_comments`.

That single file creates every table (profiles, purchases, questions,
answers, shares, comments, likes, reading buddies, progress) with the
correct security rules already applied, so users can only ever edit their
own data.

### 1.3 Get your API keys

1. Go to **Project Settings → API**.
2. Copy the **Project URL** and the **`anon` `public`** key.
3. Open `js/config.js` in this project and paste them in:

   ```js
   SUPABASE_URL: 'https://your-project-ref.supabase.co',
   SUPABASE_ANON_KEY: 'eyJhbGciOi...',   // the long anon key
   ```

4. Re-deploy: drag the folder onto Netlify again (**Deploys → drag and
   drop**), or connect the folder to GitHub and let Netlify auto-deploy on
   every push (see Stage 3 below for the GitHub route).

Accounts, sign-in, Q&A, testimonies, and reading buddies now work. Payment
still shows a "not configured" message until Stage 2.

### 1.4 (Optional) Make someone a Pastor

Anyone can currently post an answer in the Q&A — that matches "answered by
church members and pastors" from the brief. If you'd like pastors labeled
as such in the UI:

1. Have that person sign up on the site normally first.
2. In Supabase, go to **Table Editor → profiles**, find their row, and
   change `role` from `member` to `pastor` (or `admin`).

If you'd rather *restrict* answering to pastors/admins only, open
`supabase/schema.sql`, find the policy `"Signed-in users can answer
questions"`, and swap its condition for
`public.current_user_role() in ('pastor','admin')`, then re-run just that
`create policy` statement in the SQL editor (drop the old one first with
`drop policy "Signed-in users can answer questions" on public.answers;`).

---

## Stage 2 — Turn on payment (Paystack + Netlify Functions)

Paystack requires a **secret key** that must never appear in browser code —
if it did, anyone could read it and create fake successful payments. So the
actual payment steps run on two small serverless functions
(`netlify/functions/paystack-init.js` and `paystack-webhook.js`), which is
why this stage needs Netlify specifically (GitHub Pages can't run server
code).

### 2.1 Create a Paystack account

1. Go to [paystack.com](https://paystack.com) → sign up as a business (you
   can start in **Test Mode**, take a real payment with a test card to
   confirm everything works, then switch to **Live Mode** once you're ready
   to accept real money).
2. Go to **Settings → API Keys & Webhooks**.
3. Copy the **Public Key** (starts with `pk_test_` or `pk_live_`) and the
   **Secret Key** (starts with `sk_test_` or `sk_live_`).

### 2.2 Add the public key to the site

In `js/config.js`:

```js
PAYSTACK_PUBLIC_KEY: 'pk_test_xxxxxxxxxxxxxxxxxxxxx',
DEVOTIONAL_PRICE: 500000,   // ₦5,000 in kobo (multiply naira by 100)
DEVOTIONAL_CURRENCY: 'NGN',
FREE_PREVIEW_DAYS: 3,       // how many days are free before the paywall
```

### 2.3 Add the secret keys to Netlify (never to config.js)

1. In Netlify: **Site settings → Environment variables → Add a variable**.
2. Add three variables:

   | Key | Value |
   |---|---|
   | `SUPABASE_URL` | same Project URL from Stage 1.3 |
   | `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Project Settings → API → **`service_role` `secret`** key (different from the anon key — keep this one truly secret) |
   | `PAYSTACK_SECRET_KEY` | the Paystack secret key from step 2.1 |

3. **Deploys → Trigger deploy → Clear cache and deploy site** so the
   functions pick up the new variables.

### 2.4 Point Paystack's webhook at your site

1. Back in Paystack → **Settings → API Keys & Webhooks → Webhook URL**,
   enter:

   ```
   https://YOUR-SITE-NAME.netlify.app/.netlify/functions/paystack-webhook
   ```

2. Save.

That's the whole payment system: a member clicks **Pay With Paystack** on
`account.html`, `paystack-init` creates a pending record, Paystack's popup
takes the payment, and the moment it succeeds, Paystack calls
`paystack-webhook`, which flips their access on. The full 30 days unlock
automatically — no manual approval needed.

### 2.5 Test it

In Test Mode, Paystack accepts card number `4084 0840 8408 4081`, any future
expiry date, CVV `408`, and OTP `123456`. Confirm the paywall lifts after a
test payment, then switch `PAYSTACK_PUBLIC_KEY` and the Netlify
`PAYSTACK_SECRET_KEY` to your `_live_` keys when you're ready to take real
payments.

---

## Stage 3 — (Optional) Deploy from GitHub instead of drag-and-drop

Recommended once you're past the "just get it live" phase, since every
future change (e.g. updating `js/sermons.js` each day) becomes a simple
GitHub edit that auto-deploys.

1. Create a new **private** GitHub repository (private, since it will
   eventually reference your project structure, even though the actual
   secret keys never live in the repo).
2. Upload this whole folder to it (via GitHub's web upload, GitHub Desktop,
   or `git push`).
3. In Netlify: **Add new site → Import an existing project → GitHub** →
   pick the repo. Leave build settings as default (this site has no build
   step — publish directory is `.`, which `netlify.toml` already sets).
4. Netlify will now redeploy automatically every time you push a change.

**GitHub Pages** is also a fine host for the site itself, but Stage 2
(payment) won't work there, since GitHub Pages can't run the serverless
functions. If GitHub Pages is a hard requirement, you can host the two
Netlify functions separately (Netlify's free function-only usage, or any
other Node-friendly host) and point `account.html`'s `fetch('/.netlify/...')`
calls at that URL instead — ask your developer to adjust the two `fetch`
paths in `account.html` if you go this route.

---

## Adding each day's sermon

Open `js/sermons.js`. For each day, paste the video's embed URL:

```js
window.SERMONS = {
  1: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
  2: 'https://www.youtube.com/embed/xxxxxxxxxxx',
};
```

To get a YouTube embed URL: open the video → **Share → Embed** → copy the
URL inside `src="..."`. Days left out of the list simply show no video —
nothing breaks.

---

## If the devotional text ever needs correcting

The site's devotional content (`js/devotional-data.js`) was generated from
`Copy_of_Next_Level_Prayer-_30_Day_Devotional_For_Harvesters_Prayer_And_Fasting.docx`,
which was confirmed as the accurate source (the PDF had layout errors).
If the church revises the Word document later, the `parse-source/` folder
has the extraction script and instructions to regenerate
`js/devotional-data.js` — or send the updated document to whoever maintains
the site and ask them to re-run it.

---

## Troubleshooting

- **"Accounts aren't set up yet" message** → `js/config.js` still has the
  placeholder Supabase values. Re-check Stage 1.3.
- **Payment button does nothing / errors** → check the browser console
  (right-click → Inspect → Console). Usually means the Netlify environment
  variables (Stage 2.3) aren't set, or the site needs redeploying after
  adding them.
- **Paid but still locked** → the webhook (Stage 2.4) may not be reachable
  yet, or the webhook URL is mistyped. Check Paystack → **Settings → API
  Keys & Webhooks** for delivery logs, and Netlify → **Functions → 
  paystack-webhook → logs** for errors.
- **Q&A / testimonies say "couldn't load"** → check that `supabase/schema.sql`
  ran successfully with no errors (Stage 1.2), and that Realtime is enabled
  for those tables (Database → Replication).
