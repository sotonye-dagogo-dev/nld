# Regenerating js/devotional-data.js

Only needed if the church revises the devotional text later.

1. Convert the updated Word document to markdown:

   ```bash
   pandoc -t markdown "Updated Devotional.docx" -o devotional_raw.md
   ```

2. Put that `devotional_raw.md` in this folder (replacing the old one).
3. Run:

   ```bash
   pip install beautifulsoup4
   python3 extract_devotional.py
   ```

   This writes `devotional_days.json` in this folder.

4. Turn it into the JS file the site actually loads:

   ```bash
   python3 -c "
import json
data = json.load(open('devotional_days.json'))
js = 'window.DEVOTIONAL_DAYS = ' + json.dumps(data, ensure_ascii=False, indent=2) + ';'
open('../js/devotional-data.js', 'w', encoding='utf-8').write(js)
"
   ```

5. Check `../js/devotional.js` — the `PARTS` array at the top maps day
   ranges to "Part" section headers. If the day count or part boundaries
   changed, update that array to match.

Requires `pandoc` installed locally (or use any online docx→markdown
converter and skip step 1).
