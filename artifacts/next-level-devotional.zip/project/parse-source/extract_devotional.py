import re, json, subprocess
from bs4 import BeautifulSoup, Tag

with open('devotional_raw.md', encoding='utf-8') as f:
    text = f.read()

# fix common escaped punctuation before pandoc conversion
text = text.replace("\\'", "'").replace('\\"', '"')

day_pattern = re.compile(r'(?m)^(?:#{1,4}\s*)?\*{0,2}\s*DAY\s+(\d{1,2})\b[:.]?\s*\**\s*(.*)$', re.I)
matches = list(day_pattern.finditer(text))

def title_len(raw_title):
    t = re.sub(r'\{#.*$', '', raw_title).strip()
    t = re.sub(r'\*+', '', t).strip()
    return len(t)

filtered = []
seen = set()
last_num = 0
for m in matches:
    num = int(m.group(1))
    if num in seen or num != last_num + 1 or title_len(m.group(2)) > 100:
        continue
    filtered.append(m)
    seen.add(num)
    last_num = num

def md_to_html(md):
    p = subprocess.run(['pandoc', '-f', 'markdown', '-t', 'html'], input=md,
                        capture_output=True, text=True, encoding='utf-8')
    return p.stdout

def clean_text(s):
    return re.sub(r'\s+', ' ', s).strip()

SECTION_HEADS = {
    'main texts', 'introduction', 'body', 'conclusion', 'prayer points',
    'kids corner', 'reflection questions', 'practical steps of faith',
    "let's pray together", 'say to your kids', 'key truth', 'closing charge'
}

days = []
for i, m in enumerate(filtered):
    num = int(m.group(1))
    start = m.start()
    end = filtered[i+1].start() if i+1 < len(filtered) else len(text)
    chunk = text[start:end]

    title_raw = m.group(2)
    title = re.sub(r'\{#.*$', '', title_raw).strip()
    title = re.sub(r'\*+', '', title).strip()
    rest_after = chunk[m.end()-start:]
    if len(title) < 3:
        for line in rest_after.split('\n'):
            lc = re.sub(r'\*+', '', line).strip()
            lc = re.sub(r'\{#.*$', '', lc).strip()
            if lc:
                title = lc
                break
    title = title.title() if title.isupper() else title

    html = md_to_html(chunk)
    soup = BeautifulSoup(html, 'html.parser')
    all_tags = [c for c in soup.children if isinstance(c, Tag)]

    # Drop leading tags that are just "DAY N" and the title/subtitle repeat
    lead_remove = []
    for tag in all_tags:
        tx = clean_text(tag.get_text())
        if (re.match(rf'^DAY\s+{num}\b', tx, re.I)
                or tx.strip().lower() == title.strip().lower()
                or tx.strip().lower() == re.sub(r'\*+', '', title_raw).strip().lower()):
            lead_remove.append(tag)
        else:
            break
    for t in lead_remove:
        t.decompose()

    remaining = [t for t in all_tags if t.parent is not None]

    # Extract main texts (for a "scripture reference" badge) without removing it from flow
    main_texts = ''
    for tag in remaining:
        tx = clean_text(tag.get_text())
        if tx.lower().startswith('main texts'):
            main_texts = clean_text(tx.split(':', 1)[-1]) if ':' in tx else ''
            if not main_texts and tag.name and tag.name.startswith('h'):
                idx = remaining.index(tag)
                if idx+1 < len(remaining):
                    main_texts = clean_text(remaining[idx+1].get_text())
            break

    # Promote all headings to h3 for consistent styling, and drop heading if it's just a bolded
    # section label already obvious from context (keep them all, simplest + safest)
    for tag in remaining:
        if tag.name and re.match(r'h[1-6]$', tag.name):
            tag.name = 'h3'
        # strip pandoc id attributes
        if tag.has_attr('id'):
            del tag['id']

    content_html = ''.join(str(t) for t in remaining)
    content_html = content_html.replace(' class="unnumbered"', '')
    content_html = re.sub(r'<(em|strong)>_+', r'<\1>', content_html)
    content_html = re.sub(r'_+</(em|strong)>', r'</\1>', content_html)
    content_html = re.sub(r'(?<=[>\s])_(?=[“"A-Z])', '', content_html)

    days.append({
        'day': num,
        'title': title,
        'main_texts': main_texts,
        'content_html': content_html.strip(),
    })

with open('devotional_days.json', 'w', encoding='utf-8') as f:
    json.dump(days, f, indent=2, ensure_ascii=False)

for d in days:
    print(d['day'], d['title'][:45], '| len', len(d['content_html']), '| texts:', d['main_texts'][:50])
